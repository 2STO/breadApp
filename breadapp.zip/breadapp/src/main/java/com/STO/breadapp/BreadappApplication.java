package com.STO.breadapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BreadappApplication {

	public static void main(String[] args) {
		SpringApplication.run(BreadappApplication.class, args);
	}

}
